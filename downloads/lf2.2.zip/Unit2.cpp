//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TFormedit *Formedit;
//---------------------------------------------------------------------------
__fastcall TFormedit::TFormedit(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormedit::Button2Click(TObject *Sender)
{
 Close();        
}
//---------------------------------------------------------------------------
