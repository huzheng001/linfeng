//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TFormmain : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TLabel *Labeltime;
        TPanel *Panel1;
        TScrollBar *ScrollBar1;
        TLabel *Labelye;
        TBitBtn *BitBtnexit;
        TBitBtn *BitBtn1;
        TLabel *Label1;
        TPopupMenu *PopupMenu1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TTimer *Timer1;
        TBitBtn *BitBtn2;
        TBitBtn *BitBtn3;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn5;
        TBitBtn *BitBtn6;
        TBitBtn *BitBtn7;
        TBitBtn *BitBtn8;
        TBitBtn *BitBtn9;
        TBitBtn *BitBtn10;
        TBitBtn *BitBtn11;
        TBitBtn *BitBtn12;
        TBitBtn *BitBtn13;
        TBitBtn *BitBtn14;
        TBitBtn *BitBtn15;
        TBitBtn *BitBtn16;
        TBitBtn *BitBtn17;
        TBitBtn *BitBtn18;
        TBitBtn *BitBtn19;
        TBitBtn *BitBtn20;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TLabel *Label19;
        TLabel *Label20;
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall N1Click(TObject *Sender);
        void __fastcall BitBtnexitClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormmain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormmain *Formmain;
//---------------------------------------------------------------------------
#endif
