//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("Project2.res");
USEFORM("Unit1.cpp", Formmain);
USEFORM("Unit2.cpp", Formedit);
USEFORM("Unit3.cpp", Formico);
USEFORM("Unit4.cpp", Formexit);
USEFORM("Unit5.cpp", Formmima);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "�ٷ���Ϸϵͳ";
                 Application->CreateForm(__classid(TFormmain), &Formmain);
                 Application->CreateForm(__classid(TFormedit), &Formedit);
                 Application->CreateForm(__classid(TFormico), &Formico);
                 Application->CreateForm(__classid(TFormexit), &Formexit);
                 Application->CreateForm(__classid(TFormmima), &Formmima);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
