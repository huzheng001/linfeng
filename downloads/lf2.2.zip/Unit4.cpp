//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormexit *Formexit;
//---------------------------------------------------------------------------
__fastcall TFormexit::TFormexit(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormexit::Button2Click(TObject *Sender)
{
Close();
}
//---------------------------------------------------------------------------

void __fastcall TFormexit::Button1Click(TObject *Sender)
{
 if (RadioButton1->Checked) ExitWindowsEx(1,0);
     else {
       if (RadioButton1->Checked) ExitWindowsEx(2,0);
         else {
                SetSystemPowerState( true, true );
                Close();
              }
          }
}
//---------------------------------------------------------------------------

