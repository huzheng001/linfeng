//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormmain *Formmain;
//---------------------------------------------------------------------------
__fastcall TFormmain::TFormmain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormmain::Timer1Timer(TObject *Sender)
{
 Labeltime->Caption =TimeToStr(Time());
}
//---------------------------------------------------------------------------

void __fastcall TFormmain::N1Click(TObject *Sender)
{
    Formedit = new TFormedit(this);
    Formedit->ShowModal();
    delete Formedit;
}
//---------------------------------------------------------------------------

void __fastcall TFormmain::BitBtnexitClick(TObject *Sender)
{
 Formexit = new TFormexit(this);
 Formexit->ShowModal();
 delete Formexit;
}
//---------------------------------------------------------------------------

void __fastcall TFormmain::FormCreate(TObject *Sender)
{
 int a;
 a=GetSystemMetrics(SM_CXSCREEN);
 if (a==640)
   {

}
//---------------------------------------------------------------------------

