//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit5.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormmima *Formmima;
//---------------------------------------------------------------------------
__fastcall TFormmima::TFormmima(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormmima::Button2Click(TObject *Sender)
{
Close();        
}
//---------------------------------------------------------------------------


