//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormico *Formico;
//---------------------------------------------------------------------------
__fastcall TFormico::TFormico(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormico::Button2Click(TObject *Sender)
{
Close();        
}
//---------------------------------------------------------------------------

