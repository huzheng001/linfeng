//---------------------------------------------------------------------------
#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
#include "CSPIN.h"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFormedit : public TForm
{
__published:	// IDE-managed Components
        TButton *Button1;
        TButton *Button2;
        TListView *ListView1;
        TButton *Button3;
        TButton *Button4;
        TButton *Button5;
        TImage *Image1;
        TMaskEdit *MaskEdit1;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit1;
        TCSpinButton *CSpinButton1;
        TGroupBox *GroupBox1;
        TEdit *Edit2;
        TEdit *Edit3;
        TOpenDialog *OpenDialog1;
        void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormedit(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormedit *Formedit;
//---------------------------------------------------------------------------
#endif
