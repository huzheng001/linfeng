//---------------------------------------------------------------------------
#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFormico : public TForm
{
__published:	// IDE-managed Components
        TListView *ListView1;
        TButton *Button1;
        TEdit *Edit1;
        TButton *Button2;
        TButton *Button3;
        TButton *Button4;
        TLabel *Label1;
        TButton *Button5;
        TButton *Button6;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TFormico(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormico *Formico;
//---------------------------------------------------------------------------
#endif
